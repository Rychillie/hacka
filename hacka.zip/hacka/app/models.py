"""
Definition of models.
"""

from django.db import models

# Create your models here.

class Valores(models.Model):
    horario = models.DateTimeField()
    tensao = models.DecimalField( max_digits = 5, decimal_places = 2 )
    corrente = models.DecimalField( max_digits = 8, decimal_places = 2 )
    potencia_aparente = models.DecimalField( max_digits = 5, decimal_places = 2 )
    potencia_reativa = models.DecimalField( max_digits = 5, decimal_places = 2 )
    fator_de_potencia = models.DecimalField( max_digits = 5, decimal_places = 2 )
    energia_acumulada = models.DecimalField( max_digits = 20, decimal_places = 2 )
    quantidade_falta_energia = models.DecimalField( max_digits = 20, decimal_places = 2 )
    tempo_falta_energia = models.DurationField()