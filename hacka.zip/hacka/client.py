import socket
from datetime import datetime
import time
from threading import *
import sqlite3
from decimal import *


s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('192.168.43.44', 80))
timeCode = '*' + str(datetime.now()) + 'A'

def recv():
    database = "db.sqlite3"
    conn = sqlite3.connect(database)
    while True:
        print(1)
        data = s.recv(1024)
        if not data: sys.exit(0)
        data = str(data).split('*')[-1].replace('#','').replace('*','').replace('\n','').replace('\r','').replace("'",'').replace('b','').split(';')
        
        if (data != ['']):
            with conn:         
                    # tasks
                cur = conn.cursor()
                print(data)
                sql = '''INSERT INTO app_valores(horario,tensao,corrente,potencia_aparente,potencia_reativa,fator_de_potencia,energia_acumulada,quantidade_falta_energia,tempo_falta_energia) VALUES(?,?,?,?,?,?,?,?,?)'''
                task = (
                    0, 
                    (data[0]), 
                    (data[1]),
                    (data[2]),
                    (data[3]),
                    (data[4]),
                    (data[5]),
                    (data[6]), 
                    int(0))
                cur.execute(sql, task)
                print(data)
thread = Thread(target=recv)
thread.start()
while True:
    s.send(bytes(timeCode, 'utf-8'))
    time.sleep(0.07)