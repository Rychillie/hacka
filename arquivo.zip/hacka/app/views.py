"""
Definition of views.
"""

from django.shortcuts import render
from django.http import HttpRequest
from django.template import RequestContext
from datetime import datetime
from app.models import Valores
from django.http import JsonResponse
from django.http import HttpResponse

def home(request):
    """Renders the home page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/index.html',
        {
            'title':'Home Page',
            'year':datetime.now().year,
        }
    )

def getValues(request):
    valores = Valores.objects
    data = {
        'data': [[each.horario,
                      each.tensao,
                      each.corrente,
                      each.potencia_aparente,
                      each.potencia_reativa,
                      each.fator_de_potencia,
                      each.energia_acumulada,
                      each.quantidade_falta_energia,
                      each.tempo_falta_energia]
                      for each in valores.all().order_by("-id")[:12]],

    }
    return JsonResponse(data)